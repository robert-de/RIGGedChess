# Proiect Proiectarea Algoritmilor 2021 | 3 Check Chess
## Echipa

> Cioban George-Adrian

> Damian Robert-Eugen

> Stanescu Gabriel

> Strutu Ilinca-Ioana

## Organizare

* Structura proiect

Class:
    Tabla de joc este reprezentata ca un singleton pentru a putea utiliza tabla de joc
    actualizata din orice fisier al programului.
    Pentru implementarea tablei de joc folosim o matrice de 8x8 de pointeri Piece.
    Clasa Piece reprezinta baza tablei de joc, toate clasele de piese mostenind
    clasa Piece. 
    Fiecare instanta de Piece are un set de coordonate care se modifica la fiecrae mutare,
    culoarea piesei si functii de returnare a unei mutari, de verificare daca pozitia in 
    care dorim sa mutam piesa este libera sau daca este ocupata de o piesa a oponentului.
    In plus, exista o functie care returneaza un vectori de mutari valide pentru piesa 
    aleasa.

API:
    BoardAPI citeste toate imputurile de la xboard si le filtreaza in doua categorii:
    -mutari: genereaza un chessMove (structura care contine pozitia de plecare si 
             destinatia pentru o piesa, o variabila pentru cazul pormote si un flag
             pentru posibile erori); 
    -instructiuni: actualizeaza tabla de joc in functie de instructiunile primite 
                (isWhite, switchColour(), editMode, moveFlag)
    Mutarile sunt trimise apoi in main si instructiunile sunt procesate si in main se trimite o eroare.
    Se specifica xboardului caracteristicile sigint, san, done si myname

SCENARII FUNCTIONALE:
    - om ALB, bot NEGRU: pionul negru poate captura alte piese, poate inainta si poate 
    promova (regina); in cazul in care pionul ramane fara miscari se da automat resign 
    si acelasi lucru se intampla dupa ce face promote
    - newgame: se reinitializeaza tabla de joc
    - modul force: oprese gandirea botului si omul muta manual ambele seturi de piese

Debug:
    In debugAPI se receptioneaza comenzile primite de la xboard si cele trimise de noi.
    In debugTable se afiseaza pas cu pas tabla de joc, actualizata dupa fiecare mutare.

OBS: 
    Dureaza cateva secunde pana se incarca xboard-ul

