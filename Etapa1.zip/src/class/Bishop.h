#ifndef BISHOP_H
#define BISHOP_H

#include <vector>
#include "../api/boardAPI.h"
#include "Piece.h"

class Bishop : public Piece
{
private:
    /* data */
public:
    Bishop();
    Bishop(int color, int file, int rank, char type);
    ~Bishop();
    
    bool checkUnderAttack();
    std::vector<chessMove> possibleMoves();
};

#endif