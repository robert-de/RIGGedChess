#include "Knight.h"
#include "../libs.hpp"
#include <vector>

// DONE: constructori

//TODO: checkUnderAttack; possibleMoves

Knight::Knight(){

}

Knight::~Knight(){

}

Knight::Knight(int colour, int file, int rank, char type) : Piece(colour, file, rank, type){

}


    

