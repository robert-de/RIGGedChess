#include "Rook.h"
#include <vector>
#include "../libs.hpp"

Rook::Rook(int colour, int file, int rank, char type, bool moved) : Piece(colour, file, rank, type){
    this->setMoved(moved);
}

Rook::Rook(){

}

Rook::~Rook(){

}

bool Rook::getMoved(){
    return this->moved;
}

void Rook::setMoved(bool m){
    this->moved= m;
}






