#ifndef QUEEN_H
#define QUEEN_H

#include <vector>
#include "../api/boardAPI.h"
#include "Piece.h"

class Queen : public Piece
{
private:
    /* data */
public:
    Queen(int colour, int file, int rank, char type);
    Queen(/* args */);
    ~Queen();

    bool checkUnderAttack();
    std::vector<chessMove> possibleMoves();
};

#endif