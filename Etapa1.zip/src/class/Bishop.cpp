#include "Bishop.h"
#include "../libs.hpp"
#include <vector>

//DONE: constructor

//TODO: checkUnderAttack(); 


Bishop::Bishop(int colour, int file, int rank, char type) : Piece(colour, file, rank, type) {
}

Bishop::Bishop() : Piece() {

}

Bishop::~Bishop(){

}

// bool Bishop::checkUnderAttack(){

// }
    
// std::vector<chessMove> Bishop::possibleMoves(){

// }
