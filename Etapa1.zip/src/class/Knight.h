#ifndef KNIGHT_H
#define KNIGHT_H

#include <vector>
#include "../api/boardAPI.h"
#include "Piece.h"

class Knight : public Piece
{
private:
    /* data */
public:
    Knight(int colour, int file, int rank, char type);
    Knight();
    ~Knight();

    bool checkUnderAttack();
    std::vector<chessMove> possibleMoves();
};

#endif