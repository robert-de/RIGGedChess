#include "Piece.h"
#include "../api/boardAPI.h"
#include "Table.h"

Piece::Piece(int colour, int file, int rank, char type) {
    this->setColor(colour);
    this->setFile(file);
    this->setRank(rank);
    this->setType(type);
}

Piece::Piece() {

}

Piece::~Piece() {}

int Piece::getRank(){
    return this->rank;
}

int Piece::getFile(){
    return this->file;
}

int Piece::getColor(){
    return this->color;
}

char Piece::getType(){
    return this->type;
}

void Piece::setColor(int c){
    this->color = c;
}

void Piece::setRank(int r){
    this->rank = r;
}

void Piece::setFile(int f){
    this->file = f;
}

void Piece::setType(char t){
    this->type = t;
}

void Piece::updatePosition(chessMove M){
    this->setFile(M.df - 'a');
    this->setRank(M.dr - '1');
}

chessMove Piece::returnMove(int sf, int sr, int df, int dr, char promote){
    chessMove m;

    m.sf = sf + 97;
    m.sr = sr + 49;

    m.df = df + 97;
    m.dr = dr + 49;

    m.num_sf = sf;
    m.num_sr = sr;

    m.num_df = df;
    m.num_dr = sr;

    m.promote = promote;

    m.error = 0;

    return m;

}

bool Piece::checkCapture(int f, int r, int myColour){
    Table* gameTable = Table::getInstance();
    Piece*** matrix = gameTable->getMatrix();
    if((!this->checkFree(f, r)))
        if(matrix[r][f]->getColor() != myColour)
            return true;
    return false;
}

bool Piece::checkFree(int f, int r){
    Table* gameTable = Table::getInstance();
    Piece*** matrix = gameTable->getMatrix();
    if(matrix[r][f] == NULL)
        return true;
    else
        return false;
}


