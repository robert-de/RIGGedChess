#include "Table.h"
Table * Table :: singleton = NULL;

Table::Table() : logfile("debugTable", std::ofstream::out) {

    this->pieceMatrix = (Piece***) malloc(8 * sizeof(Piece**));
    for(int i = 0; i < 8; i++) {
        this->pieceMatrix[i] = (Piece**) malloc(8 * sizeof(Piece*));
    }
    
    this->editMode = false;
}

Table::~Table()
{
}

Table* Table:: getInstance() {
    if (!Table :: singleton)
      Table :: singleton = new Table();
    return Table :: singleton;
}

// False = black
// True = white
void Table::switchColor(bool color) {
    if(color) {
        this->selectedPawnRank = 1;
        this->selectedPawnFile = 1;

    } else {
        this->selectedPawnRank = 6;
        this->selectedPawnFile = 6;    
    }
    this->selectedPawn = (Pawn *) (this->getMatrix())[this->selectedPawnRank][this->selectedPawnFile];
}
void Table::tableInit() {

    this->turn = true;
    this->editMode = false;
    this->exit = false;
    // PAWNS
    for (int i = 0; i < 8; i++) {
        // WHITE
        this->pieceMatrix[1][i] = new Pawn(1, i, 1, 'P');
        // BLACK
        this->pieceMatrix[6][i] = new Pawn(-1, i, 6, 'p');
    }

    // WHITE ROOKS
    this->pieceMatrix[0][0] = new Rook(1, 0, 0, 'R', false);
    this->pieceMatrix[0][7] = new Rook(1, 0, 7, 'R', false);
    // BLACK ROOKS
    this->pieceMatrix[7][0] = new Rook(-1, 7, 0, 'r', false);
    this->pieceMatrix[7][7] = new Rook(-1, 7, 7, 'r', false);

    // WHITE BISHOPS
    this->pieceMatrix[0][2] = new Bishop(1, 0, 2, 'B');
    this->pieceMatrix[0][5] = new Bishop(1, 0, 5, 'B');
    // BLACK BISHOPS
    this->pieceMatrix[7][2] = new Bishop(-1, 7, 2, 'b');
    this->pieceMatrix[7][5] = new Bishop(-1, 7, 5, 'b');

    // WHITE KNIGHTS
    this->pieceMatrix[0][1] = new Knight(1, 0, 1, 'N');
    this->pieceMatrix[0][6] = new Knight(1, 0, 6, 'N');
    // BLACK KNIGHTS
    this->pieceMatrix[7][1] = new Knight(-1, 7, 1, 'n');
    this->pieceMatrix[7][6] = new Knight(-1, 7, 6, 'n');

    // WHITE ROYAL COUPLE
    this->pieceMatrix[0][4] = new King(1, 0, 4, 'K', false);
    this->pieceMatrix[0][3] = new Queen(1, 0, 3, 'Q');
    // BLACK ROYAL COUPLE
    this->pieceMatrix[7][4] = new King(-1, 7, 4, 'k', false);
    this->pieceMatrix[7][3] = new Queen(-1, 7, 3, 'q');
   
    for (int i = 2; i < 6 ; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            this->pieceMatrix[i][j] = NULL; 
        }
        
    }
    
    this->debugDraw();
}

Piece*** Table::getMatrix(){
    return this->pieceMatrix;
}


void Table::debugDraw() {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            if(this->pieceMatrix[i][j] == NULL)
                this->logfile << "  ";
            else
                this->logfile << this->pieceMatrix[i][j]->getType() << " " ;
        }
        this->logfile << std::endl;
    }
    this->logfile << std::endl;
}


void Table::updateTable(chessMove newMove) {
    if (this->pieceMatrix[newMove.sr - '1'][newMove.sf - 'a'] != NULL) {
        this->pieceMatrix[newMove.dr - '1'][newMove.df - 'a'] = this->pieceMatrix[newMove.sr - '1'][newMove.sf - 'a'];
        this->pieceMatrix[newMove.sr - '1'][newMove.sf - 'a'] = NULL;
        this->pieceMatrix[newMove.dr - '1'][newMove.df - 'a']->updatePosition(newMove);
    }
    this->debugDraw();
}

Pawn* Table::getPiece(chessMove m){
    Pawn* p = (Pawn *) this->pieceMatrix[m.dr - '1'][m.df - 'a'];
    return p;
}
