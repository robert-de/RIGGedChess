#ifndef PAWN_H
#define PAWN_H

#include <vector>
#include "../api/boardAPI.h"
#include "Piece.h"
//#include "Table.h"

class Pawn : public Piece {
    private:
        /* data */
    public:
        Pawn();
        Pawn(int colour, int file, int rank, char type);
        ~Pawn();

        bool checkUnderAttack();
        std::vector<chessMove> possibleMoves(); 
        
        void promote();
};

#endif
