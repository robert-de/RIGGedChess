#include "King.h"
#include "Piece.h"
#include "../api/boardAPI.h"

//DONE: constructor; getMoved; setMoved

//TODO: checkChess(); possibleMoves()

King::King(int color, int file, int rank, int type, bool move) : Piece(color, file, rank, type)
{
    this->moved = moved;
}

King::King() : Piece(){

}

King::~King()
{
}

void King::setMoved(bool m){
    this->moved = m;
} 

bool King::getMoved(){
    return this->moved;
}


