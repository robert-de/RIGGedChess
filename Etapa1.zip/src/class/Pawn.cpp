#include "Pawn.h"
#include "../libs.hpp"
#include <vector>

Pawn::Pawn(int colour, int file, int rank, char type) : Piece(colour, file, rank, type) {
}

Pawn::~Pawn() {
}

Pawn::Pawn() : Piece() {

}

std::vector<chessMove> Pawn::possibleMoves(){

   std::vector<chessMove> v;

    if((this->getRank() == 0) || (this->getRank() == 7))
        return v;

   int r, f;
   chessMove m;
   /* Pawn not moved: move one space or two spaces */
     if(this->getColor() == 1){
        /*left*/
        if(checkCapture(this->getFile() - 1, this->getRank() + 1, this->getColor())){
            r = this->getRank() + 1;
            f = this->getFile() - 1;
            if(r == 7 || r == 0)
                m = returnMove(this->getFile(), this->getRank(), f, r, 113);
            else
                m = returnMove(this->getFile(), this->getRank(), f, r, 65);
            v.insert(v.begin() + v.size(), m);
        }
        /*right*/
        if(checkCapture(this->getFile() + 1, this->getRank() + 1, this->getColor())){
            r = this->getRank() + 1;
            f = this->getFile() + 1;
            if(r == 7 || r == 0)
                m = returnMove(this->getFile(), this->getRank(), f, r, 113);
            else
                m = returnMove(this->getFile(), this->getRank(), f, r, 65);
            v.insert(v.begin() + v.size(), m);
        }
    }
    /*capture black*/
    else{
        /*left*/
        if(checkCapture(this->getFile() - 1, this->getRank() - 1, this->getColor())){
            r = this->getRank() - 1;   
            f = this->getFile() - 1;
            if(r == 7 || r == 0)
                m = returnMove(this->getFile(), this->getRank(), f, r, 113);
            else
                m = returnMove(this->getFile(), this->getRank(), f, r, 65);
            v.insert(v.begin() + v.size(), m);
        }
        /*right*/
        if(checkCapture(this->getFile() + 1, this->getRank() - 1, this->getColor())){
            r = this->getRank() - 1;
            f = this->getFile() + 1;
            if(r == 7 || r == 0)
                m = returnMove(this->getFile(), this->getRank(), f, r, 113);
            else
                m = returnMove(this->getFile(), this->getRank(), f, r, 65);
            v.insert(v.begin() + v.size(), m);
        }
    }

    if(/*white*/ (this->getRank() == 1 && this->getColor() == 1) || /*black*/(this->getRank() == 6 && this->getColor() == -1)){
        /* one space*/
        r = this->getRank() + this->getColor();
        f = this->getFile();
        if(this->checkFree(f, r)){
            m = returnMove(this->getFile(), this->getRank(), f, r, 65);
            v.insert(v.begin() + v.size(), m);
        }

        /* two spaces*/
        r = this->getRank() +   2 * this->getColor();
        f = this->getFile();
        if(this->checkFree(f, r)){
            m = returnMove(this->getFile(), this->getRank(), f, r, 65);
            v.insert(v.begin() + v.size(), m);
        }
    }

    /* promote */
    if(/*white*/ (this->getRank() == 6 && this->getColor() == 1) || /*black*/ (this->getRank() == 1 && this->getColor() == -1)){
           
        r = this->getRank() + this->getColor();
        f = this->getFile();
        if(this->checkFree(f, r)){
            // //bishop
            // m = returnMove(this->getFile(), this->getRank(), f, r, 98);
            // v.insert(v.begin() + v.size(), m);

            // //knight
            // m = returnMove(this->getFile(), this->getRank(), f, r, 110);
            // v.insert(v.begin() + v.size(), m);

            //queen
            m = returnMove(this->getFile(), this->getRank(), f, r, 113);
            v.insert(v.begin() + v.size(), m);
        }

    }

    /* one space between ranks 3 and 6 */
    if((this->getRank() < 6) && (this->getRank() > 1)){
        r = this->getRank() +   this->getColor();
        f = this->getFile();
        if(this->checkFree(f, r)){
           m = returnMove(this->getFile(), this->getRank(), f, r, 65);
           v.insert(v.begin() + v.size(), m);
         }


        
    }
    
    return v;

}
