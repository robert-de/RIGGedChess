#ifndef TABLE_H
#define TABLE_H

#include "Piece.h"
#include "Pawn.h"
#include "Bishop.h"
#include "King.h"
#include "Queen.h"
#include "Rook.h"
#include "Knight.h"

class Table
{
private:
    Piece*** pieceMatrix;
   
public:
    static Table *singleton;
    Table();
    ~Table();


    Pawn * selectedPawn;
    int selectedPawnRank;
    int selectedPawnFile;

    Piece*** getMatrix();
    bool isWhite; 

    // Engine turn?
    bool turn;
    // Force mode enabled?
    bool editMode;
    // For the quit command
    bool exit;
    static Table *getInstance();
    void tableInit();
    void debugDraw();
    std::ofstream logfile;
    void updateTable(chessMove); 
    Pawn* getPiece(chessMove m);
    void switchColor(bool color);
};

#endif