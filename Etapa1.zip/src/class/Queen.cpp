#include "Queen.h"
#include "../libs.hpp"
#include <vector>


Queen::Queen(int colour, int file, int rank, char type) : Piece(colour, file, rank, type){

}

Queen::Queen(){

}

Queen::~Queen(){

}

