
#ifndef PIECE_H
#define PIECE_H

#include <vector>
#include "../api/boardAPI.h"
//#include "Table.h"

class Piece {
private:
    /* data */
    int file; /*from 0 to 7 */
    int rank; /* from 0 to 7 */
    int color; /* -1 negru 1 alb */
    std::vector<chessMove> moves;
    char type;
    // Pawn p
    // Rook r
    // Knight n
    // Bishop b
    // Queen q
    // King k
public:
    Piece();
    Piece(int colour, int file, int rank, char type) ;
    ~Piece();

    int getColor();
    int getFile();
    int getRank();
    char getType();

    void setColor(int c);
    void setFile(int f);
    void setRank(int r);
    void setType(char t);

    chessMove returnMove(int sf, int sr, int df, int dr, char promote);

    void updatePosition(chessMove M);
    
    bool checkCapture(int f, int r, int myColour);

    bool checkFree(int f, int r);
};

chessMove returnMove(int sf, int sr, int df, int dr);

#endif
