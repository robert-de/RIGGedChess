# CLASS DESCRIPTIONS

## Piece 
Type:
    
    Abstract Class
Fields:

    int8 status;
        Color > (0 = Black / 1 = White)
        State > (0 = Dead  / 1 = Alive)
    int8
        posX;
    int8
        posY; 
Methods:

    #TODO
#
## Table
Type:
    
    #TODO
Fields:

    #TODO
Methods:

    #TODO