#ifndef __LIBS__
#define __LIBS__

// SYS INCLUDES
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

// CPP INCLUDES
#include <iostream>
#include <fstream>
#include <sstream>
#include <string.h>
#include <vector>

// RIGGED INCLUDES
#include "./api/boardAPI.h"


// DEFINES
#define forever while(1)

#endif