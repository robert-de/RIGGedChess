#include "boardAPI.h"
#include "../libs.hpp"
#include "../class/Table.h"

boardAPI::boardAPI() : logfile("debugAPI", std::ofstream::app) {
    this->init();
}

boardAPI::~boardAPI() {}

// Filters content in API buffer and validates a move format
chessMove boardAPI::getMove() {
    chessMove newMove;
    this->getCommandBuffer();

    if(!this->filter())
        newMove.error = 1;
    else
        newMove.error = 0;

    int cmdLen;
    cmdLen = strlen(this->commBuffer);
    
    // COORDINATE VALUES
    newMove.sf = this->commBuffer[cmdLen - 5];
    newMove.sr = this->commBuffer[cmdLen - 4];
    newMove.df = this->commBuffer[cmdLen - 3];
    newMove.dr = this->commBuffer[cmdLen - 2];

    // NUMERIC VALUES
    newMove.num_sf = this->commBuffer[cmdLen - 5] - 'a';
    newMove.num_sr = this->commBuffer[cmdLen - 4] - '1';
    newMove.num_df = this->commBuffer[cmdLen - 3] - 'a';
    newMove.num_dr = this->commBuffer[cmdLen - 2] - '1';

    if(newMove.error == 0) {
        this->logfile << "OPPONENT MOVE: [" << newMove.sf << newMove.sr << newMove.df << newMove.dr << "]" << std::endl; 
    }
        
    return newMove;
}

// Validates a move char array
bool boardAPI::validMoveFormat(char* move){
    this->logfile << "VALIDATING: [" << move << "]" << std::endl; 

    bool moveFlags[4] = {false, false, false, false};
    if(move[0] >= 'a' && move[0] <= 'h')
        moveFlags[0] = true;
    if(move[2] >= 'a' && move[2] <= 'h')
        moveFlags[2] = true;
    if(move[1] >= '1' && move[1] <= '8')
        moveFlags[1] = true;
    if(move[3] >= '1' && move[3] <= '8')
        moveFlags[3] = true;
    
    if(moveFlags[0] && moveFlags[1] && moveFlags[2] && moveFlags[3])
        return true;
    else
        return false;      
}

// Checks is there is at least one valid format move in the API buffer 
bool boardAPI::filter() {
    this->logfile << "IN FILTER: \n[\n" << this->commBuffer << "]" << std::endl; 
    std::stringstream stringStream(this->commBuffer);
    Table* gameTable = Table::getInstance();
    char process[25];
    
    bool moveFlag = false;
    while(stringStream >> process) {
        this->logfile << "PROCESSING: [" << process << "]" << std::endl; 

        if(strcmp(process, "new") == 0) {
            gameTable->isWhite = false;
            gameTable->tableInit();
            gameTable->switchColor(false);
            this->logfile << "NEW GAME" << std::endl; 
        } else if(strcmp(process, "white") == 0) {
            gameTable->isWhite = true;
            gameTable->switchColor(true);
            this->logfile << "PLAYING AS WHITE" << std::endl; 
        } else if(strcmp(process, "black") == 0) {
            gameTable->isWhite = false;
            gameTable->switchColor(false);
            this->logfile << "PLAYING AS BLACK" << std::endl; 
        } else if(strcmp(process, "go") == 0) {
            this->logfile << "GO" << std::endl; 
            gameTable->turn = !gameTable->turn;
        } else if(strcmp(process, "force") == 0) {
            this->logfile << "EDIT MODE ENABLED" << std::endl; 
        } else if(strcmp(process, "quit") == 0) {
            this->logfile << "QUITTING" << std::endl; 
            gameTable->exit = true;
        }

        if(strlen(process) != 4)
            continue;
        else if(validMoveFormat(process)){
            moveFlag = true;
            break;
        }     
    }

    if(moveFlag){
        this->logfile << "PASSED: [" << process << "]" << std::endl; 
        return true;
    } else 
        return false;
}

// Sends engineMove to STDOUT
void boardAPI::sendMove(chessMove engineMove) {
    if(engineMove.promote == 'A') {
        char moveCommand[10] = {'m', 'o', 'v', 'e', ' ', engineMove.sf, engineMove.sr, engineMove.df, engineMove.dr, '\n'};
        this->logfile << "ATTEMPTING MOVE: [" << engineMove.sf << engineMove.sr << engineMove.df << engineMove.dr << "]" << std::endl; 
        write(STDOUT_FILENO, moveCommand, 10);
    } else {
        char moveCommand[11] = {'m', 'o', 'v', 'e', ' ', engineMove.sf, engineMove.sr, engineMove.df, engineMove.dr, engineMove.promote, '\n'};
        this->logfile << "ATTEMPTING MOVE: [" << engineMove.sf << engineMove.sr << engineMove.df << engineMove.dr << engineMove.promote << "]" << std::endl; 
        write(STDOUT_FILENO, moveCommand, 11);
    }
}

// Adds chars from STDIN to the command buffer
void boardAPI::getCommandBuffer() {
    strcpy(this->commBuffer, "\0");
    int len;
    // Declare a file descriptor
    fd_set stdinDescriptor;
    // Clear the file descriptor
    FD_ZERO(&stdinDescriptor);
    // Set it to 0 (STDIN)
    FD_SET(0, &stdinDescriptor);
    select(1, &stdinDescriptor, NULL, NULL, NULL);
    len = read(STDIN_FILENO, this->commBuffer, APIBUF_SIZE);
    this->commBuffer[len] = 0;
    this->logfile << "COMMAND READ: \n[\n" << this->commBuffer << "]" << std::endl;
    if(len < 0){
        perror("Error while getting a new command");
        exit(-1);
    }
    this->bufferLen = len;
}

int boardAPI::init() {
    // Get initial XBoard command
    this->getCommandBuffer();
    if (this->commBuffer[0] == 'x') {
        write(STDOUT_FILENO, "\n", 1);
        // After getting Protover N command send features
        this->getCommandBuffer();
        // Disable signals
        write(STDOUT_FILENO, "feature sigint=0\n", 17);
        // Get/Send moves in coordinate notations ex: e2e4
        write(STDOUT_FILENO, "feature san=0\n", 14);
        // Name of engine
        write(STDOUT_FILENO, "feature myname=\"Rigged\"\n", 24);
        // All settings have been sent, start the game
        write(STDOUT_FILENO, "feature done=1\n", 15);
        // Initialised flag set to true and game loop can be entered
        this->initialised = true;
    }
    return 0;
}