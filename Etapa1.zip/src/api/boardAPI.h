#include "../libs.hpp"

#ifndef API_H
#define API_H

#define APIBUF_SIZE 100

enum CMD_OUTS {
    featureCMD,
    resignCMD,
    moveCMD
};

enum FILTER {
    moveFilter,
    timeFilter
};

typedef struct chessMove chessMove;

struct chessMove {
    char sf;
    char sr;
    char df;
    char dr;

    char num_sf;
    char num_sr;
    char num_df;
    char num_dr;

    char promote;


    bool error; /*move format at output*/
};

class boardAPI {
    private:
    public:
    char commBuffer[APIBUF_SIZE];
    char bufferLen;
    bool initialised;

    boardAPI();
    ~boardAPI();

    std::ofstream logfile;

    int init();
    void getCommandBuffer();
    int sendCommand(int type, char* command);
    chessMove getMove();
    bool filter();
    void sendMove(chessMove engineMove);
    bool validMoveFormat(char* move);
};

#endif