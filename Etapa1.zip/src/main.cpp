#include "libs.hpp"

#include "class/Table.h"

int main() {
    // Initialize the API with all required features
    boardAPI api;
    Table* gameTable = Table::getInstance();
    gameTable->tableInit();
    gameTable->switchColor(false);

    // Process additional input from XBoard
    chessMove opponentMove;
    chessMove engineMove;
    
    std::vector<chessMove> availPawnMoves;

    forever {

        // If bot plays as white and it's white's turn, don't wait for opponent move
        opponentMove = api.getMove();

        // If the quit command is received, break out of infinite loop and return 0
        if(gameTable->exit)
            break;

        // Resign if our pawn was captured
        if(gameTable->selectedPawn->getRank() == opponentMove.num_dr && gameTable->selectedPawn->getFile() == opponentMove.num_df){
            write(STDOUT_FILENO, "resign\n", 7);
            gameTable->tableInit();
            gameTable->switchColor(false);
        }

        // SEND A MOVE
        if(opponentMove.error != 1) {
            gameTable->turn = !gameTable->turn;
            // If edit mode is enabled stop thinking, only update the table with incoming moves
            if(!gameTable->editMode) {
                gameTable->updateTable(opponentMove);
                availPawnMoves = gameTable->selectedPawn->possibleMoves();
                if (!availPawnMoves.empty()) {
                    api.sendMove(availPawnMoves.front());
                    gameTable->turn = !gameTable->turn;
                    gameTable -> updateTable(availPawnMoves.front());
                }
                else {
                    write(STDOUT_FILENO, "resign\n", 7);
                    gameTable->tableInit();
                    gameTable->switchColor(false);
                }
                gameTable->selectedPawn = gameTable->getPiece(availPawnMoves.front());
            } else 
                gameTable->updateTable(opponentMove);
            
        }
    }

    return 0;
}