#include "chessMove.hpp"

chessMove::chessMove(/* args */)
{
}

chessMove::~chessMove()
{
}
